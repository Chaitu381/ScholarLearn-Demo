import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Flame,
  Send,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { codeconnectHubStats } from "../../../data/codeconnectMockData";
import { cn } from "../../../../../shared/utils/cn";
import { MCQQuestionCard } from "./MCQQuestionCard";
import { MCQResultReview } from "./MCQResultReview";
import {
  formatCategoryLabel,
  formatDifficultyLabel,
  getQuestionNumber,
  type MCQPracticeCategory,
  type MCQPracticeQuestion,
} from "./mcqPracticeTypes";

type MCQPracticeWorkspaceProps<TQuestion extends MCQPracticeQuestion> = {
  category: MCQPracticeCategory;
  initialQuestionId?: string;
  onBackToHub: () => void;
  questions: TQuestion[];
  subtitle?: string;
  title?: string;
};

export function MCQPracticeWorkspace<TQuestion extends MCQPracticeQuestion>({
  category,
  initialQuestionId,
  onBackToHub,
  questions,
  subtitle,
  title,
}: MCQPracticeWorkspaceProps<TQuestion>) {
  const initialQuestion = useMemo(
    () => questions.find((question) => question.id === initialQuestionId) ?? questions[0],
    [initialQuestionId, questions],
  );

  const sessionQuestions = useMemo(() => {
    if (!initialQuestion) {
      return questions;
    }

    const sameTopicQuestions = questions.filter(
      (question) => question.topic === initialQuestion.topic,
    );

    return sameTopicQuestions.length > 0 ? sameTopicQuestions : questions;
  }, [initialQuestion, questions]);

  const initialSessionIndex = Math.max(
    sessionQuestions.findIndex((question) => question.id === initialQuestion?.id),
    0,
  );

  const [currentIndex, setCurrentIndex] = useState(initialSessionIndex);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, string>>({});
  const [submittedQuestionIds, setSubmittedQuestionIds] = useState<string[]>([]);
  const [bookmarkedQuestionIds, setBookmarkedQuestionIds] = useState<string[]>([]);
  const [isFinished, setIsFinished] = useState(false);

  useEffect(() => {
    setCurrentIndex(initialSessionIndex);
    setSelectedAnswers({});
    setSubmittedQuestionIds([]);
    setBookmarkedQuestionIds([]);
    setIsFinished(false);
  }, [initialSessionIndex, initialQuestionId]);

  const selectedQuestion = sessionQuestions[currentIndex];

  const handlePreviousQuestion = () => {
    if (sessionQuestions.length === 0) {
      return;
    }

    setCurrentIndex((index) => (index === 0 ? sessionQuestions.length - 1 : index - 1));
  };

  const handleNextQuestion = () => {
    if (sessionQuestions.length === 0) {
      return;
    }

    setCurrentIndex((index) => (index === sessionQuestions.length - 1 ? 0 : index + 1));
  };

  const handleSubmitCurrentAnswer = () => {
    if (!selectedQuestion || !selectedAnswers[selectedQuestion.id]) {
      return;
    }

    setSubmittedQuestionIds((currentIds) =>
      currentIds.includes(selectedQuestion.id)
        ? currentIds
        : [...currentIds, selectedQuestion.id],
    );
  };

  const handleToggleBookmark = () => {
    if (!selectedQuestion) {
      return;
    }

    setBookmarkedQuestionIds((currentIds) =>
      currentIds.includes(selectedQuestion.id)
        ? currentIds.filter((questionId) => questionId !== selectedQuestion.id)
        : [...currentIds, selectedQuestion.id],
    );
  };

  const handleRetryPractice = () => {
    setCurrentIndex(initialSessionIndex);
    setSelectedAnswers({});
    setSubmittedQuestionIds([]);
    setBookmarkedQuestionIds([]);
    setIsFinished(false);
  };

  if (isFinished) {
    return (
      <MCQResultReview
        onBackToList={onBackToHub}
        onRetry={handleRetryPractice}
        questions={sessionQuestions}
        selectedAnswers={selectedAnswers}
      />
    );
  }

  if (!selectedQuestion) {
    return (
      <section className="min-h-screen bg-background p-4 text-text-primary sm:p-6">
        <div className="rounded-3xl border border-dashed border-border bg-surface p-8 text-center shadow-card">
          <h2 className="text-[22px] font-extrabold text-text-primary">
            No questions found
          </h2>
          <p className="mt-2 text-[14px] font-bold leading-6 text-text-secondary">
            Go back to the list and choose another question.
          </p>
          <button
            type="button"
            onClick={onBackToHub}
            className="mt-5 h-11 rounded-2xl bg-primary px-5 text-[13px] font-extrabold text-white transition hover:bg-primary-dark"
          >
            Back to list
          </button>
        </div>
      </section>
    );
  }

  const categoryLabel = formatCategoryLabel(category);
  const answeredCount = Object.keys(selectedAnswers).length;

  return (
    <section className="min-h-screen bg-background text-text-primary">
      <div className="sticky top-0 z-50 border-b border-border bg-surface/95 backdrop-blur">
        <div className="mx-auto flex min-h-[86px] max-w-[1440px] flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onBackToHub}
              className="inline-flex h-11 items-center gap-2 rounded-2xl bg-surface-soft px-4 text-[13px] font-extrabold text-text-primary transition hover:bg-primary-soft hover:text-primary-dark"
            >
              <ArrowLeft aria-hidden="true" size={17} />
              Back to List
            </button>

            <span className="inline-flex h-9 items-center rounded-2xl bg-surface-soft px-4 text-[12px] font-extrabold text-text-secondary">
              {selectedQuestion.topic}
            </span>

            <span className="inline-flex h-9 items-center rounded-2xl bg-primary-soft px-4 text-[12px] font-extrabold text-primary-dark">
              {formatDifficultyLabel(selectedQuestion.difficulty)}
            </span>

            <span className="inline-flex h-9 items-center rounded-2xl bg-blue-soft px-4 text-[12px] font-extrabold text-blue">
              Question {currentIndex + 1}/{sessionQuestions.length}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex h-11 items-center gap-2 rounded-2xl bg-orange-soft px-4 text-[13px] font-extrabold text-orange">
              <Flame aria-hidden="true" size={16} />
              {codeconnectHubStats.activeStreakDays}d
            </span>

            <span className="inline-flex h-11 items-center gap-2 rounded-2xl bg-yellow-soft px-4 text-[13px] font-extrabold text-text-primary">
              <Zap aria-hidden="true" size={16} />
              {codeconnectHubStats.practiceXp.toLocaleString()} XP
            </span>

            <button
              type="button"
              onClick={handlePreviousQuestion}
              className="inline-flex h-11 items-center gap-2 rounded-2xl border border-border bg-surface-soft px-4 text-[13px] font-extrabold text-text-primary transition hover:border-primary hover:bg-primary-soft hover:text-primary-dark"
            >
              <ChevronLeft aria-hidden="true" size={17} />
              Previous
            </button>

            <button
              type="button"
              onClick={handleNextQuestion}
              className="inline-flex h-11 items-center gap-2 rounded-2xl border border-border bg-surface-soft px-4 text-[13px] font-extrabold text-text-primary transition hover:border-primary hover:bg-primary-soft hover:text-primary-dark"
            >
              Next
              <ChevronRight aria-hidden="true" size={17} />
            </button>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-[1440px] px-4 py-5 sm:px-6 lg:px-8 lg:py-8">
        <section className="mb-4 rounded-[1.5rem] bg-surface-soft p-4 sm:p-5">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-text-muted">
            CodeConnect {categoryLabel}
          </p>
          <h1 className="mt-1 text-[24px] font-extrabold leading-tight text-text-primary">
            {title ?? `${categoryLabel} MCQ Workspace`}
          </h1>
          <p className="mt-1 text-[13px] font-bold leading-6 text-text-secondary">
            {subtitle ?? `Started from question ${getQuestionNumber(selectedQuestion)}. This session includes questions from ${selectedQuestion.topic}.`}
          </p>

          <div className="mt-4 flex flex-wrap gap-2">
            {sessionQuestions.map((question, index) => {
              const isCurrent = index === currentIndex;
              const isAnswered = Boolean(selectedAnswers[question.id]);
              const isSubmitted = submittedQuestionIds.includes(question.id);

              return (
                <button
                  key={question.id}
                  type="button"
                  onClick={() => setCurrentIndex(index)}
                  className={cn(
                    "grid h-10 w-10 place-items-center rounded-2xl text-[12px] font-extrabold transition",
                    isCurrent
                      ? "bg-primary text-white"
                      : isSubmitted
                        ? "bg-primary-soft text-primary-dark"
                        : isAnswered
                          ? "bg-blue-soft text-blue"
                          : "bg-surface text-text-secondary hover:bg-primary-soft hover:text-primary-dark",
                  )}
                  aria-label={`Go to question ${index + 1}`}
                >
                  {index + 1}
                </button>
              );
            })}
          </div>
        </section>

        <MCQQuestionCard
          currentIndex={currentIndex}
          isBookmarked={bookmarkedQuestionIds.includes(selectedQuestion.id)}
          isSubmitted={submittedQuestionIds.includes(selectedQuestion.id)}
          onNextQuestion={handleNextQuestion}
          onSelectAnswer={(answer) =>
            setSelectedAnswers((currentAnswers) => ({
              ...currentAnswers,
              [selectedQuestion.id]: answer,
            }))
          }
          onSubmitAnswer={handleSubmitCurrentAnswer}
          onToggleBookmark={handleToggleBookmark}
          question={selectedQuestion}
          selectedAnswer={selectedAnswers[selectedQuestion.id]}
          totalQuestions={sessionQuestions.length}
        />

        <div className="mt-5 flex flex-col gap-3 rounded-[1.5rem] border border-border bg-surface p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between">
          <p className="text-[13px] font-bold text-text-secondary">
            Answered {answeredCount} of {sessionQuestions.length}. You can change answers before finishing.
          </p>

          <button
            type="button"
            onClick={() => setIsFinished(true)}
            className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-primary px-6 text-[14px] font-extrabold text-white transition hover:bg-primary-dark"
          >
            <Send aria-hidden="true" size={17} />
            Submit All / Finish Practice
          </button>
        </div>
      </main>
    </section>
  );
}
