import { ArrowLeft, CheckCircle2, RotateCcw, XCircle } from "lucide-react";
import { cn } from "../../../../../shared/utils/cn";
import {
  getCorrectAnswerValue,
  getQuestionPoints,
  getQuestionText,
  isAnswerCorrect,
  normalizeQuestionOptions,
  type MCQPracticeQuestion,
} from "./mcqPracticeTypes";

type MCQResultReviewProps<TQuestion extends MCQPracticeQuestion> = {
  onBackToList: () => void;
  onRetry: () => void;
  questions: TQuestion[];
  selectedAnswers: Record<string, string>;
};

export function MCQResultReview<TQuestion extends MCQPracticeQuestion>({
  onBackToList,
  onRetry,
  questions,
  selectedAnswers,
}: MCQResultReviewProps<TQuestion>) {
  const attemptedCount = questions.filter((question) => selectedAnswers[question.id]).length;
  const correctCount = questions.filter((question) =>
    isAnswerCorrect(question, selectedAnswers[question.id]),
  ).length;
  const wrongCount = attemptedCount - correctCount;
  const skippedCount = questions.length - attemptedCount;
  const percentageScore = Math.round((correctCount / Math.max(questions.length, 1)) * 100);
  const xpEarned = questions.reduce(
    (total, question) =>
      isAnswerCorrect(question, selectedAnswers[question.id])
        ? total + getQuestionPoints(question)
        : total,
    0,
  );

  return (
    <section className="min-h-screen bg-background text-text-primary">
      <div className="sticky top-0 z-50 border-b border-border bg-surface/95 backdrop-blur">
        <div className="mx-auto flex min-h-[76px] max-w-[1440px] flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6 lg:px-8">
          <button
            type="button"
            onClick={onBackToList}
            className="inline-flex h-11 items-center gap-2 rounded-2xl bg-surface-soft px-4 text-[13px] font-extrabold text-text-primary transition hover:bg-primary-soft hover:text-primary-dark"
          >
            <ArrowLeft aria-hidden="true" size={17} />
            Back to Question List
          </button>

          <button
            type="button"
            onClick={onRetry}
            className="inline-flex h-11 items-center gap-2 rounded-2xl bg-primary px-5 text-[13px] font-extrabold text-white transition hover:bg-primary-dark"
          >
            <RotateCcw aria-hidden="true" size={17} />
            Retry Practice
          </button>
        </div>
      </div>

      <main className="mx-auto max-w-[1440px] px-4 py-5 sm:px-6 lg:px-8 lg:py-8">
        <section className="rounded-[1.5rem] bg-surface-soft p-4 sm:p-5">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-text-muted">
            Practice complete
          </p>
          <h1 className="mt-1 text-[28px] font-extrabold text-text-primary">
            Score: {percentageScore}%
          </h1>

          <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-6">
            <ReviewStat label="Total" value={questions.length} />
            <ReviewStat label="Attempted" value={attemptedCount} />
            <ReviewStat label="Correct" value={correctCount} />
            <ReviewStat label="Wrong" value={wrongCount} />
            <ReviewStat label="Skipped" value={skippedCount} />
            <ReviewStat label="XP Earned" value={xpEarned} />
          </div>
        </section>

        <section className="mt-5 grid gap-3">
          {questions.map((question, index) => {
            const selectedAnswer = selectedAnswers[question.id];
            const isSkipped = !selectedAnswer;
            const isCorrect = isAnswerCorrect(question, selectedAnswer);
            const correctAnswer = getCorrectAnswerValue(question);
            const options = normalizeQuestionOptions(question);
            const selectedLabel = options.find((option) => option.value === selectedAnswer)?.label;
            const correctLabel = options.find((option) => option.value === correctAnswer)?.label;

            return (
              <article
                key={question.id}
                className="rounded-[1.5rem] border border-border bg-surface p-4 shadow-sm"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded-full bg-surface-soft px-3 py-1 text-[12px] font-extrabold text-text-secondary">
                        #{index + 1}
                      </span>
                      <span className="rounded-full bg-surface-soft px-3 py-1 text-[12px] font-extrabold text-text-secondary">
                        {question.topic}
                      </span>
                      <span className="rounded-full bg-yellow-soft px-3 py-1 text-[12px] font-extrabold text-text-primary">
                        {getQuestionPoints(question)} XP
                      </span>
                    </div>
                    <h2 className="mt-3 text-[17px] font-extrabold leading-7 text-text-primary">
                      {getQuestionText(question)}
                    </h2>
                  </div>

                  <span
                    className={cn(
                      "inline-flex items-center gap-2 rounded-full px-3 py-1 text-[12px] font-extrabold",
                      isSkipped
                        ? "bg-surface-soft text-text-secondary"
                        : isCorrect
                          ? "bg-primary-soft text-primary-dark"
                          : "bg-red-soft text-red",
                    )}
                  >
                    {isSkipped ? null : isCorrect ? (
                      <CheckCircle2 aria-hidden="true" size={14} />
                    ) : (
                      <XCircle aria-hidden="true" size={14} />
                    )}
                    {isSkipped ? "Skipped" : isCorrect ? "Correct" : "Wrong"}
                  </span>
                </div>

                <div className="mt-4 grid gap-3 lg:grid-cols-2">
                  <AnswerBox
                    label="Your answer"
                    value={
                      selectedAnswer
                        ? `${selectedLabel ? `${selectedLabel}. ` : ""}${selectedAnswer}`
                        : "Skipped"
                    }
                  />
                  <AnswerBox
                    label="Correct answer"
                    value={`${correctLabel ? `${correctLabel}. ` : ""}${correctAnswer || "Not provided"}`}
                  />
                </div>

                <div className="mt-4 rounded-2xl bg-surface-soft p-4">
                  <p className="text-[12px] font-extrabold uppercase tracking-wide text-text-muted">
                    Explanation
                  </p>
                  <p className="mt-2 text-[14px] font-bold leading-6 text-text-secondary">
                    {question.explanation ?? "No explanation available."}
                  </p>
                </div>
              </article>
            );
          })}
        </section>
      </main>
    </section>
  );
}

function ReviewStat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl bg-surface p-4 shadow-card">
      <p className="text-[11px] font-extrabold uppercase tracking-wide text-text-muted">
        {label}
      </p>
      <p className="mt-1 text-[24px] font-extrabold text-text-primary">
        {value}
      </p>
    </div>
  );
}

function AnswerBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-surface-soft p-4">
      <p className="text-[12px] font-extrabold uppercase tracking-wide text-text-muted">
        {label}
      </p>
      <p className="mt-2 text-[14px] font-extrabold leading-6 text-text-primary">
        {value}
      </p>
    </div>
  );
}
