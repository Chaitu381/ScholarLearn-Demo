import { ArrowLeft, ChevronLeft, ChevronRight, Flame, Zap } from "lucide-react";
import type { CodingLanguage, CodingProblem, Difficulty } from "../../../types/codeconnect.types";

type CodingTopBarProps = {
  backAriaLabel?: string;
  backLabel?: string;
  language: CodingLanguage;
  onBackToHub: () => void;
  onLanguageChange: (language: CodingLanguage) => void;
  onNextProblem: () => void;
  onPreviousProblem: () => void;
  practiceXp: number;
  problem: CodingProblem;
  streakDays: number;
};

const difficultyClasses: Record<Difficulty, string> = {
  easy: "bg-primary-soft text-primary-dark",
  medium: "bg-orange-soft text-orange",
  hard: "bg-red-soft text-red",
};

const languageLabels: Record<CodingLanguage, string> = {
  java: "Java",
  python: "Python",
  javascript: "JavaScript",
  cpp: "C++",
};

export function CodingTopBar({
  backAriaLabel = "Back to CodeConnect Dashboard",
  backLabel = "Back",
  language,
  onBackToHub,
  onLanguageChange,
  onNextProblem,
  onPreviousProblem,
  practiceXp,
  problem,
  streakDays,
}: CodingTopBarProps) {
  return (
    <header className="flex min-h-16 flex-col gap-3 border-b border-border bg-surface px-3 py-3 sm:px-4 lg:min-h-[72px] lg:flex-row lg:items-center lg:justify-between">
      <div className="flex min-w-0 items-center gap-3">
        <button
          type="button"
          className="inline-flex h-10 shrink-0 items-center gap-2 rounded-2xl bg-surface-soft px-3 text-[13px] font-extrabold text-text-primary transition hover:bg-primary-soft hover:text-primary-dark"
          onClick={onBackToHub}
          aria-label={backAriaLabel}
        >
          <ArrowLeft aria-hidden="true" size={17} strokeWidth={2.5} />
          <span>{backLabel}</span>
        </button>
        {/* <div className="min-w-0">
          <p className="text-[12px] font-extrabold uppercase text-text-muted">CodeConnect</p>
          <h1 className="truncate text-[18px] font-extrabold leading-6 text-text-primary sm:text-[20px]">{problem.title}</h1>
        </div> */}
        <div className="flex min-w-0 pl-3 flex-wrap items-center gap-2 lg:justify-center">
          <span className="rounded-full bg-surface-soft px-3 py-1 text-[12px] font-extrabold text-text-secondary">
            Difficulty: <strong className="text-text-primary">{capitalize(problem.difficulty)}</strong>
          </span>
          <span className="rounded-full bg-blue-soft px-3 py-1 text-[12px] font-extrabold text-blue">
            Problem: {problem.problemNumber ?? problem.id}
          </span>
          <span className={`rounded-full px-3 py-1 text-[12px] font-extrabold ${difficultyClasses[problem.difficulty]}`}>
            {capitalize(problem.difficulty)}
          </span>
        </div>
      </div>

      

      <div className="flex min-w-0 flex-wrap items-center gap-2 lg:justify-end">
        <span className="hidden h-10 items-center gap-2 rounded-2xl bg-orange-soft px-3 text-[12px] font-extrabold text-orange md:inline-flex">
          <Flame aria-hidden="true" size={14} strokeWidth={2.5} />
          {streakDays}d
        </span>
        <span className="hidden h-10 items-center gap-2 rounded-2xl bg-yellow-soft px-3 text-[12px] font-extrabold text-text-primary md:inline-flex">
          <Zap aria-hidden="true" size={14} strokeWidth={2.5} />
          {practiceXp.toLocaleString()} XP
        </span>
        <button
          type="button"
          className="inline-flex h-10 items-center gap-1 rounded-2xl border border-border bg-surface-soft px-3 text-[13px] font-extrabold text-text-primary transition hover:border-primary hover:text-primary-dark"
          onClick={onPreviousProblem}
        >
          <ChevronLeft aria-hidden="true" size={17} strokeWidth={2.5} />
          <span className="hidden sm:inline">Previous Problem</span>
          <span className="sm:hidden">Prev</span>
        </button>
        <button
          type="button"
          className="inline-flex h-10 items-center gap-1 rounded-2xl border border-border bg-surface-soft px-3 text-[13px] font-extrabold text-text-primary transition hover:border-primary hover:text-primary-dark"
          onClick={onNextProblem}
        >
          <span className="hidden sm:inline">Next Problem</span>
          <span className="sm:hidden">Next</span>
          <ChevronRight aria-hidden="true" size={17} strokeWidth={2.5} />
        </button>
      </div>
    </header>
  );
}

function capitalize(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}
