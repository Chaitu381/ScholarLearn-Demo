import { ArrowLeft, GraduationCap, Network, Zap } from "lucide-react";
import type { PracticeCategory } from "../../types/codeconnect.types";

type CodeConnectHeaderProps =
  | {
      onReturnToStudentDashboard: () => void;
      practiceXp: number;
      streakDays: number;
      variant: "dashboard";
    }
  | {
      activePracticeMode: PracticeCategory;
      backAriaLabel?: string;
      backLabel?: string;
      onBackToHub: () => void;
      practiceXp: number;
      streakDays: number;
      variant?: "module";
    };

type HeaderRightProps = {
  practiceXp: number;
  streakDays: number;
};

const modeTitles: Record<PracticeCategory, string> = {
  coding: "Coding Practice",
  aptitude: "Aptitude Practice",
  reasoning: "Reasoning Practice",
  verbal: "Verbal Practice",
};

export function CodeConnectHeader({ practiceXp, streakDays, ...props }: CodeConnectHeaderProps) {
  if (props.variant === "dashboard") {
    return (
      <header className="grid min-h-16 grid-cols-[1fr_auto] items-center gap-3 border-b border-border bg-surface px-4 sm:px-5 lg:min-h-[72px] lg:grid-cols-[28%_1fr_28%]">
        <div className="flex min-w-0 items-center gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-primary text-white">
            <Network aria-hidden="true" size={21} strokeWidth={2.5} />
          </span>
          <span className="min-w-0">
            <span className="block truncate text-[16px] font-extrabold text-text-primary">CodeConnect</span>
            <span className="hidden text-[12px] font-bold text-text-secondary sm:block">Practice dashboard</span>
          </span>
        </div>

        <button
          type="button"
          className="order-3 col-span-2 mx-auto flex min-w-0 items-center justify-center gap-3 rounded-2xl px-3 py-2 text-center transition hover:bg-surface-soft lg:order-none lg:col-span-1"
          onClick={props.onReturnToStudentDashboard}
          aria-label="Return to ScholarLearn Student Dashboard"
        >
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-blue-soft text-blue">
            <GraduationCap aria-hidden="true" size={21} strokeWidth={2.5} />
          </span>
          <span className="min-w-0">
            <span className="block truncate text-[18px] font-extrabold text-text-primary">ScholarLearn</span>
            <span className="hidden text-[12px] font-bold text-text-secondary sm:block">Student Dashboard</span>
          </span>
        </button>

        <HeaderRight practiceXp={practiceXp} streakDays={streakDays} />
      </header>
    );
  }

  const {
    activePracticeMode,
    backAriaLabel = "Back to CodeConnect Dashboard",
    backLabel = "Back to dashboard",
    onBackToHub,
  } = props;

  return (
    <header className="grid min-h-16 grid-cols-[1fr_auto] items-center gap-3 border-b border-border bg-surface px-4 py-2 sm:px-5 lg:min-h-[72px] lg:grid-cols-[28%_1fr_28%]">
      <button
        type="button"
        className="flex min-w-0 items-center gap-3 rounded-2xl text-left transition hover:bg-surface-soft"
        onClick={onBackToHub}
        aria-label={backAriaLabel}
      >
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-primary text-white">
          <ArrowLeft aria-hidden="true" size={20} strokeWidth={2.5} />
        </span>
        <span className="min-w-0">
          <span className="block truncate text-[16px] font-extrabold text-text-primary">CodeConnect</span>
          <span className="hidden text-[12px] font-bold text-text-secondary sm:block">{backLabel}</span>
        </span>
      </button>

      <div className="hidden min-w-0 text-center lg:block">
        <h1 className="truncate text-[20px] font-extrabold text-text-primary">{modeTitles[activePracticeMode]}</h1>
      </div>

      <HeaderRight practiceXp={practiceXp} streakDays={streakDays} />

      <div className="col-span-2 min-w-0 pb-2 text-center lg:hidden">
        <h1 className="truncate text-[18px] font-extrabold text-text-primary">{modeTitles[activePracticeMode]}</h1>
      </div>
    </header>
  );
}

function HeaderRight({ practiceXp, streakDays }: HeaderRightProps) {
  return (
    <div className="flex items-center justify-end gap-2">
      <StatPill label="Streak" value={`${streakDays}d`} />
      <StatPill label="XP" value={practiceXp.toLocaleString()} icon />
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-blue-soft text-[13px] font-extrabold text-blue">
        C
      </span>
    </div>
  );
}

function StatPill({ icon = false, label, value }: { icon?: boolean; label: string; value: string }) {
  return (
    <span className="hidden h-10 items-center gap-2 rounded-2xl bg-surface-soft px-3 text-[12px] font-extrabold text-text-secondary sm:inline-flex">
      {icon ? <Zap aria-hidden="true" size={14} strokeWidth={2.5} className="text-orange" /> : null}
      <span>{label}</span>
      <strong className="text-text-primary">{value}</strong>
    </span>
  );
}
